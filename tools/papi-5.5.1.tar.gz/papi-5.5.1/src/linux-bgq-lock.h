extern void _papi_hwd_lock( int );
extern void _papi_hwd_unlock( int );
