int _solaris_get_memory_info( PAPI_hw_info_t * hw, int id );
int _solaris_get_dmem_info( PAPI_dmem_info_t * d );
int _niagara2_get_memory_info( PAPI_hw_info_t * hw, int id );
