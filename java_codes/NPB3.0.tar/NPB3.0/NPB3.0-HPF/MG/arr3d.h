        type arr3d
          double precision, pointer :: ar(:,:,:)
        end type arr3d
