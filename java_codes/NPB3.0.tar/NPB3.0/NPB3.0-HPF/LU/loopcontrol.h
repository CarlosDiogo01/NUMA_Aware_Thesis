      type LoopControlStruct
        integer :: updown, updowne, topseg, botseg
        integer :: section1, section2, section3
        integer :: xsize, ysize, zsize
        integer :: first, last
      end type LoopControlStruct
