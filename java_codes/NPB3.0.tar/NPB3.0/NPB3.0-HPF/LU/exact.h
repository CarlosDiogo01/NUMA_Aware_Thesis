      integer, intent(in) :: i, j, k
      double precision, dimension(:), intent(out) ::  u000ijk
