      integer jfirst, jlast, ifirst, ilast
      integer section1, section2, section3
      integer topseg, botseg, updown, updowne
      integer xsize, ysize, zsize
      common /indexbounds/ section1, section2, section3,
     >                     topseg, botseg, updown, updowne,
     >                     jfirst, jlast, ifirst, ilast,
     >                     xsize, ysize, zsize
